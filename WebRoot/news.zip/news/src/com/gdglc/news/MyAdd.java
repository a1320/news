package com.gdglc.news;

public class MyAdd {
	public int add(int x,int y){
		return x+y;
	}
}
