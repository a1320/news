package com.gdglc.news;

public class Parent {
	
	protected Object add(int a,int b)throws RuntimeException{
		return null;
	}
}
