package com.gdglc.news.utils;
public class UuidException extends RuntimeException {

    public UuidException() {
        super();
    }

    public UuidException(String msg) {
        super(msg);
    }
}
